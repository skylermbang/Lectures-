from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from .models import Result

import json
# Create your views here.


def skyler(request):
    return HttpResponse(" This is skyler yo 1")


@require_http_methods(['GET', 'POST'])
@csrf_exempt
def home(request):
    if request.method == 'GET':
        return render(request, 'website/index.html')
    if request.method == 'POST':
        data = json.loads(request.body)
        result = Result(
            username=data['username'],
            user_card=data['user_card'],
            feature1_card=data['feature1_card'],
            feature2_card=data['feature2_card'],
            booster_card=data['booster_card'],
            problems=data['problems'],
            solutions=data['solutions'],
            what=data['what'],
            why=data['why'],
            how=data['how']
        )
        result.save()
        return HttpResponse("OK")


def submit(request):
    # return HttpResponse("Questionnaire submitted. Thank you!")
    return render(request, "website/submit.html")


def tips(request):
    return render(request, "website/tips.html")


def new(request):
    return render(request, "website/new.html")
