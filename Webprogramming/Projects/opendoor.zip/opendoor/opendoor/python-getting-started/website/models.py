from django.db import models

# Create your models here.


class Result(models.Model):
    username = models.CharField(max_length=50, default="")
    user_card = models.CharField(max_length=50, default="")
    feature1_card = models.CharField(max_length=50, default="")
    feature2_card = models.CharField(max_length=50, default="")
    booster_card = models.CharField(max_length=50, default="")
    problems = models.CharField(max_length=1000, default="")
    solutions = models.CharField(max_length=1000, default="")
    what = models.CharField(max_length=1000, default="")
    why = models.CharField(max_length=1000, default="")
    how = models.CharField(max_length=1000, default="")
