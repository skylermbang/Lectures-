from django.urls import path, include
from .views import home, submit, tips, new

urlpatterns = [
    path('', home),
    path('submit/', submit),
    path('tips', tips, name="tips"),
    path('new', new, name="new"),
]
