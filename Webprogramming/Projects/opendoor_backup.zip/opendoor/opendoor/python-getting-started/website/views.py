from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.


def skyler(request):
    return HttpResponse(" This is skyler yo 1")


def home(request):
    return render(request, "website/index.html")
