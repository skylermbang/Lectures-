// <⚠️ DONT DELETE THIS ⚠️>
import "./styles.css";
// <⚠️ /DONT DELETE THIS ⚠️>

const TODOFORM = document.getElementById("js-form");
const INPUT = TODOFORM.querySelector("input");
const PENDINGLIST = document.getElementById("js-pending-list");
const FINISHELIST = document.getElementById("js-finisehd-list");

const TODOS_LS = "Task List ";
const FINISHED_LS = "Finishied List";

let TODOLIST = [];
let FINISHEDLIST = [];

function finished(event) {
  const btn2 = event.target;
  const li = btn2.parentNode;
  //let text = li.firstChild.innerText;
  li.parentNode.removeChild(li);
  const FinishedToDos = TODOLIST.filter(function filterFn(toDo) {
    //console.log(toDo.id, parseInt(li.id), "testing for finished");
    return toDo.id !== parseInt(li.id);
  });
  console.log(FinishedToDos, "checking new todo list");

  const FinishedToDos2 = TODOLIST.filter(function filterFn(toDo2) {
    return toDo2.id === parseInt(li.id);
  });
  console.log(FinishedToDos2, "checking new finished list");

  let Finished_text = li.firstChild.innerText;
  const FINISHED_TEXT = Finished_text;
  paintFinished(FINISHED_TEXT);

  TODOLIST = FinishedToDos;
  saveToDos();
  saveToDos2();
}

function delTodo(event) {
  const btn1 = event.target;
  const li = btn1.parentNode;
  li.parentNode.removeChild(li);
  const cleanToDos = TODOLIST.filter(function filterFn(toDo) {
    console.log(toDo.id, li.id);
    return toDo.id !== parseInt(li.id);
  });

  console.log(cleanToDos);
  TODOLIST = cleanToDos;
  saveToDos();
}

function delTodo2(event) {
  const btn1 = event.target;
  const li = btn1.parentNode;
  li.parentNode.removeChild(li);
  const cleanToDos2 = FINISHEDLIST.filter(function filterFn(toDo) {
    console.log(toDo.id, li.id);
    return toDo.id !== parseInt(li.id);
  });

  FINISHEDLIST = cleanToDos2;
  saveToDos2();
}

function saveToDos() {
  localStorage.setItem(TODOS_LS, JSON.stringify(TODOLIST));
}

function saveToDos2() {
  localStorage.setItem(FINISHED_LS, JSON.stringify(FINISHEDLIST));
}

function paintTodo(text) {
  const li = document.createElement("li");

  const btn1 = document.createElement("button"); // save btn
  btn1.innerText = " ❌";
  btn1.addEventListener("click", delTodo);
  const btn2 = document.createElement("button"); // del btn
  btn2.innerText = " ✅";
  btn2.addEventListener("click", finished);

  const span = document.createElement("span");
  const newId = TODOLIST.length + 1;

  span.innerText = text;
  li.appendChild(span);
  li.appendChild(btn1);
  li.appendChild(btn2);
  li.id = newId;

  PENDINGLIST.appendChild(li);
  const toDoObj = {
    text: text,
    id: newId
  };
  TODOLIST.push(toDoObj);

  saveToDos();
}

function paintFinished(text) {
  const li = document.createElement("li");
  const btn1 = document.createElement("button"); // save btn
  btn1.innerText = " ❌";
  btn1.addEventListener("click", delTodo2);

  const span = document.createElement("span");
  const newId = FINISHEDLIST.length + 1;

  span.innerText = text;
  li.appendChild(span);
  li.appendChild(btn1);

  li.id = newId;

  FINISHELIST.appendChild(li);
  const toDoObj2 = {
    text: text,
    id: newId
  };
  FINISHEDLIST.push(toDoObj2);
  saveToDos2();
}

function handleSubmit(event) {
  event.preventDefault();
  const currentValue = INPUT.value;
  paintTodo(currentValue);
  INPUT.value = "";
}

function loadToDos() {
  const loadedtoDos = localStorage.getItem(TODOS_LS);
  console.log(
    loadedtoDos,
    "testing for loadToDos   stringfied local stroage for TODOLIST"
  );
  if (loadedtoDos !== null) {
    const parsedToDos = JSON.parse(loadedtoDos);
    parsedToDos.forEach(function (todo) {
      paintTodo(todo.text);
    });
  }
}

function loadFinished() {
  const loadedFinished = localStorage.getItem(FINISHED_LS);
  console.log(
    loadedFinished,
    "testing for loadFinisehd stringfied local stroage for FINISHEDLIST"
  );
  if (loadedFinished !== null) {
    const parsedFinished = JSON.parse(loadedFinished);

    parsedFinished.forEach(function (finished) {
      paintFinished(finished.text);
    });
  }
}

function init() {
  TODOFORM.addEventListener("submit", handleSubmit);
  loadToDos();
  loadFinished();
}

init();
