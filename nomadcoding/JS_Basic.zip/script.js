
const document = document.getElementById("title");


title.innerHTML = "fuck !" 





/*

function sayHi(name, age){

  return (`What sup you motherfucker ${name}  and you fucker is fucking ${age} years old `)

}


const hiSkyler = sayHi( "skyler", 29);

console.log(hiSkyler);


const calculator ={

plus:function(a,b){
  return a+b;

},

minus: function(a,b){
  return a-b;
},

multiply: function(a,b){
  return a*b;
}

}

const plus = calculator.plus(5, 5);
const minus = calculator.minus(10, 5);
const multi = calculator.multiply(10, 5);
console.log(plus);
console.log(minus);
console.log(multi);