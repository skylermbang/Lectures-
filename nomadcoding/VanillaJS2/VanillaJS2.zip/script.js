//  try to get the id "title" from index.html
const title = document.getElementById("title");

console.log(title);