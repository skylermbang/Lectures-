﻿namespace DesignPatternsInCSharp.Memento
{
    // TODO: Consider refactoring to use https://github.com/ardalis/SmartEnum
    public enum GameResult
    {
        InProgress,
        Lost,
        Won
    }
}
