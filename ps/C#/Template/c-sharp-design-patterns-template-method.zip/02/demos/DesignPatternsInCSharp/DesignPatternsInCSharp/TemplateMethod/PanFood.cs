﻿namespace DesignPatternsInCSharp.TemplateMethod
{
    public abstract class PanFood
    {
        public bool RequiresBaking { get; set; } = true;
    }
}
